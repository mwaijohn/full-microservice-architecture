package com.microservice.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
